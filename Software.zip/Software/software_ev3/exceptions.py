class CalibrationDataDoesntExistsException(Exception):
    pass